=== SafeGuard GPSR EU for WooCommerce ===
Contributors: tryjfdagency
Tags: woocommerce, gpsr, eu compliance, product safety, ce marking
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Automate EU Regulation (EU) 2023/988 (GPSR) compliance for WooCommerce with per-product fields, 1-click bulk profiles, and a multilingual storefront block.

== Description ==

**SafeGuard GPSR EU for WooCommerce** helps online stores selling in the European Union comply with the **General Product Safety Regulation (EU) 2023/988 (GPSR)**.

### Key Features
* **GPSR UE Product Data Tab:** Add Manufacturer details (name, postal address, email/URL), EU Responsible Person (Art. 16 GPSR), safety warnings, and CE conformity marking directly inside WooCommerce product editing.
* **Reusable Brand & Category Profiles (1-Click Bulk Apply):** Save legal manufacturer & EU Responsible Person profiles once under `WooCommerce -> SafeGuard GPSR EU` and apply them to all products in a category or brand attribute in one click.
* **Automatic Multilingual Storefront Block:** Displays a clean, responsive compliance box (below Add to Cart or as an additional Product Tab) automatically translated into **Spanish (ES), English (EN), German (DE), and French (FR)** based on the site locale.
* **Free & Pro Editions:** Free edition supports unlimited per-product editing and up to 25 products per 1-click bulk run. Pro license unlocks unlimited bulk updates across large catalogs.
* **WooCommerce HPOS Compatible:** Built with modern WordPress/WooCommerce sanitization, nonces, and High-Performance Order Storage compatibility.

== Installation ==

1. Upload the `safeguard-gpsr-eu` folder to `/wp-content/plugins/` or install the `safeguard-gpsr-eu.zip` file via **Plugins -> Add New -> Upload Plugin**.
2. Activate the plugin through the **Plugins** menu in WordPress.
3. Go to **WooCommerce -> SafeGuard GPSR EU** to create reusable Manufacturer / EU Responsible Person profiles or edit individual products under the **GPSR UE** product data tab.

== Frequently Asked Questions ==

= What is EU Regulation 2023/988 (GPSR)? =
The General Product Safety Regulation (EU) 2023/988 requires online sellers offering consumer products in the EU to display clear manufacturer contact details, an EU-based Responsible Person (Article 16), safety warnings in the local language, and conformity details on product pages.

= Does this plugin work without an EU Responsible Person if the manufacturer is already in the EU? =
Yes. You can fill in the Manufacturer fields and list the same EU-based entity as the Responsible Person, or leave warnings optional if not applicable.

= How does the 25-product limit in the Free version work? =
You can edit individual products with no limit. When using the 1-Click Bulk Apply tool in `WooCommerce -> SafeGuard GPSR EU`, the Free plan updates up to 25 products per bulk run; activating a Pro license removes this limit.

= Which languages are supported on the storefront block? =
Labels automatically adapt to Spanish (`es`), English (`en`), German (`de`), and French (`fr`) based on your WordPress locale.

== Screenshots ==

1. WooCommerce Product Edit **GPSR UE** tab with Manufacturer, EU Responsible Person, Safety Warnings, and CE Marking fields.
2. `WooCommerce -> SafeGuard GPSR EU` reusable Brand/Category profiles and 1-Click Bulk Apply dashboard.
3. Public storefront compliance block displayed cleanly on a WooCommerce product page.

== Changelog ==

= 1.0.0 =
* Initial release with GPSR UE product tab, reusable brand/category profiles, 1-click bulk apply, Pro license key support, HPOS compatibility, and multilingual storefront block (ES/EN/DE/FR).

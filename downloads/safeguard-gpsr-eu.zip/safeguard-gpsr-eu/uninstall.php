<?php
/**
 * Fired when the plugin is uninstalled.
 *
 * @package SafeGuard_GPSR_EU
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'sg_gpsr_settings' );
delete_option( 'sg_gpsr_profiles' );

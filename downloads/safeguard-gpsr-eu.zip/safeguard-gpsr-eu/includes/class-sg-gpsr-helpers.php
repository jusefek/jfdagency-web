<?php
/**
 * Helper utilities for SafeGuard GPSR EU.
 *
 * @package SafeGuard_GPSR_EU
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SG_GPSR_Helpers {

	/**
	 * Meta keys stored per WooCommerce product.
	 *
	 * @return array<string, string>
	 */
	public static function get_meta_keys() {
		return array(
			'manufacturer_name'     => '_sg_gpsr_manufacturer_name',
			'manufacturer_address'  => '_sg_gpsr_manufacturer_address',
			'manufacturer_email'    => '_sg_gpsr_manufacturer_email',
			'eu_responsible_name'   => '_sg_gpsr_eu_responsible_name',
			'eu_responsible_addr'   => '_sg_gpsr_eu_responsible_address',
			'eu_responsible_email'  => '_sg_gpsr_eu_responsible_email',
			'safety_warnings'       => '_sg_gpsr_safety_warnings',
			'ce_marking'            => '_sg_gpsr_ce_marking',
		);
	}

	/**
	 * Retrieve sanitized GPSR compliance data for a product.
	 *
	 * @param int $product_id WooCommerce product ID.
	 * @return array<string, mixed>
	 */
	public static function get_product_gpsr_data( $product_id ) {
		$keys = self::get_meta_keys();
		$data = array();

		foreach ( $keys as $field => $meta_key ) {
			$val = get_post_meta( $product_id, $meta_key, true );
			if ( 'ce_marking' === $field ) {
				$data[ $field ] = ( 'yes' === $val || '1' === $val || true === $val );
			} else {
				$data[ $field ] = is_string( $val ) ? $val : '';
			}
		}

		return $data;
	}

	/**
	 * Save sanitized GPSR compliance data to a product.
	 *
	 * @param int                  $product_id WooCommerce product ID.
	 * @param array<string, mixed> $raw_data   Raw input values.
	 * @return void
	 */
	public static function save_product_gpsr_data( $product_id, $raw_data ) {
		$sanitized = self::sanitize_profile_data( $raw_data );
		$keys      = self::get_meta_keys();

		foreach ( $keys as $field => $meta_key ) {
			if ( 'ce_marking' === $field ) {
				update_post_meta( $product_id, $meta_key, $sanitized[ $field ] ? 'yes' : 'no' );
			} else {
				update_post_meta( $product_id, $meta_key, $sanitized[ $field ] );
			}
		}
	}

	/**
	 * Sanitize a GPSR compliance profile array.
	 *
	 * @param array<string, mixed> $raw Raw input array.
	 * @return array<string, mixed>
	 */
	public static function sanitize_profile_data( $raw ) {
		return array(
			'manufacturer_name'    => isset( $raw['manufacturer_name'] ) ? sanitize_text_field( wp_unslash( $raw['manufacturer_name'] ) ) : '',
			'manufacturer_address' => isset( $raw['manufacturer_address'] ) ? sanitize_textarea_field( wp_unslash( $raw['manufacturer_address'] ) ) : '',
			'manufacturer_email'   => isset( $raw['manufacturer_email'] ) ? sanitize_text_field( wp_unslash( $raw['manufacturer_email'] ) ) : '',
			'eu_responsible_name'  => isset( $raw['eu_responsible_name'] ) ? sanitize_text_field( wp_unslash( $raw['eu_responsible_name'] ) ) : '',
			'eu_responsible_addr'  => isset( $raw['eu_responsible_addr'] ) ? sanitize_textarea_field( wp_unslash( $raw['eu_responsible_addr'] ) ) : '',
			'eu_responsible_email' => isset( $raw['eu_responsible_email'] ) ? sanitize_text_field( wp_unslash( $raw['eu_responsible_email'] ) ) : '',
			'safety_warnings'      => isset( $raw['safety_warnings'] ) ? wp_kses_post( wp_unslash( $raw['safety_warnings'] ) ) : '',
			'ce_marking'           => ! empty( $raw['ce_marking'] ) && 'no' !== $raw['ce_marking'],
		);
	}

	/**
	 * Check whether Pro license is active.
	 *
	 * @return bool
	 */
	public static function is_pro_active() {
		$settings = get_option( 'sg_gpsr_settings', array() );
		if ( ! is_array( $settings ) ) {
			return false;
		}
		return isset( $settings['license_status'] ) && 'active' === $settings['license_status'] && ! empty( $settings['license_key'] );
	}

	/**
	 * Validate a Pro license key format (SG-GPSR-PRO-XXXX-XXXX).
	 *
	 * @param string $key License key string.
	 * @return bool
	 */
	public static function validate_license_key( $key ) {
		$clean = strtoupper( trim( sanitize_text_field( $key ) ) );
		return (bool) preg_match( '/^SG-GPSR-PRO-[A-Z0-9]{4}-[A-Z0-9]{4}$/', $clean );
	}

	/**
	 * Get localized storefront labels in ES, EN, DE, or FR.
	 *
	 * @return array<string, string>
	 */
	public static function get_storefront_labels() {
		$locale = function_exists( 'determine_locale' ) ? determine_locale() : get_locale();
		$lang   = strtolower( substr( (string) $locale, 0, 2 ) );

		$labels = array(
			'es' => array(
				'title'          => 'Seguridad del producto y cumplimiento UE (GPSR)',
				'manufacturer'   => 'Fabricante',
				'eu_responsible' => 'Persona Responsable en la UE',
				'safety'         => 'Advertencias de seguridad e instrucciones',
				'ce_badge'       => 'Conformidad CE verificada (Reglamento UE 2023/988)',
				'contact'        => 'Contacto',
			),
			'de' => array(
				'title'          => 'Produktsicherheit & EU-Konformität (GPSR)',
				'manufacturer'   => 'Hersteller',
				'eu_responsible' => 'Verantwortliche Person in der EU',
				'safety'         => 'Sicherheitshinweise und Anweisungen',
				'ce_badge'       => 'CE-Konformität bestätigt (Verordnung EU 2023/988)',
				'contact'        => 'Kontakt',
			),
			'fr' => array(
				'title'          => 'Sécurité du produit et conformité UE (GPSR)',
				'manufacturer'   => 'Fabricant',
				'eu_responsible' => 'Personne responsable dans l’UE',
				'safety'         => 'Avertissements de sécurité et instructions',
				'ce_badge'       => 'Conformité CE vérifiée (Règlement UE 2023/988)',
				'contact'        => 'Contact',
			),
			'en' => array(
				'title'          => 'Product Safety & EU Compliance (GPSR)',
				'manufacturer'   => 'Manufacturer',
				'eu_responsible' => 'EU Responsible Person',
				'safety'         => 'Safety Warnings & Instructions',
				'ce_badge'       => 'CE Conformity Verified (Regulation EU 2023/988)',
				'contact'        => 'Contact',
			),
		);

		return isset( $labels[ $lang ] ) ? $labels[ $lang ] : $labels['en'];
	}
}

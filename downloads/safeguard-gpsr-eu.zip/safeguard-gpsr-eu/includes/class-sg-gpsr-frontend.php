<?php
/**
 * Public WooCommerce Product Page GPSR Compliance Block.
 *
 * @package SafeGuard_GPSR_EU
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SG_GPSR_Frontend {

	/**
	 * Register storefront hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_styles' ) );

		$settings = get_option( 'sg_gpsr_settings', array() );
		$position = isset( $settings['display_position'] ) ? $settings['display_position'] : 'summary';

		if ( 'tab' === $position ) {
			add_filter( 'woocommerce_product_tabs', array( __CLASS__, 'add_product_tab' ) );
		} else {
			add_action( 'woocommerce_single_product_summary', array( __CLASS__, 'render_summary_box' ), 35 );
		}
	}

	/**
	 * Enqueue frontend stylesheet on single product pages.
	 *
	 * @return void
	 */
	public static function enqueue_styles() {
		if ( function_exists( 'is_product' ) && is_product() ) {
			wp_enqueue_style(
				'sg-gpsr-frontend',
				SG_GPSR_PLUGIN_URL . 'assets/css/frontend.css',
				array(),
				SG_GPSR_VERSION
			);
		}
	}

	/**
	 * Add GPSR compliance tab to single product tabs.
	 *
	 * @param array<string, array<string, mixed>> $tabs Existing product tabs.
	 * @return array<string, array<string, mixed>>
	 */
	public static function add_product_tab( $tabs ) {
		global $product;
		if ( ! $product instanceof WC_Product ) {
			return $tabs;
		}
		$data = SG_GPSR_Helpers::get_product_gpsr_data( $product->get_id() );
		if ( empty( $data['manufacturer_name'] ) && empty( $data['eu_responsible_name'] ) ) {
			return $tabs;
		}

		$labels = SG_GPSR_Helpers::get_storefront_labels();

		$tabs['sg_gpsr_eu'] = array(
			'title'    => $labels['title'],
			'priority' => 45,
			'callback' => array( __CLASS__, 'render_summary_box' ),
		);

		return $tabs;
	}

	/**
	 * Render GPSR compliance box on single product page.
	 *
	 * @return void
	 */
	public static function render_summary_box() {
		global $product;
		if ( ! $product instanceof WC_Product ) {
			return;
		}

		$data = SG_GPSR_Helpers::get_product_gpsr_data( $product->get_id() );
		if ( empty( $data['manufacturer_name'] ) && empty( $data['eu_responsible_name'] ) ) {
			return;
		}

		$labels = SG_GPSR_Helpers::get_storefront_labels();
		?>
		<div class="sg-gpsr-box" aria-label="<?php echo esc_attr( $labels['title'] ); ?>">
			<div class="sg-gpsr-header">
				<span class="sg-gpsr-title"><?php echo esc_html( $labels['title'] ); ?></span>
				<?php if ( ! empty( $data['ce_marking'] ) ) : ?>
					<span class="sg-gpsr-ce-badge">CE</span>
				<?php endif; ?>
			</div>

			<div class="sg-gpsr-grid">
				<?php if ( ! empty( $data['manufacturer_name'] ) ) : ?>
					<div class="sg-gpsr-item">
						<strong><?php echo esc_html( $labels['manufacturer'] ); ?></strong>
						<p>
							<?php echo esc_html( $data['manufacturer_name'] ); ?><br />
							<?php if ( ! empty( $data['manufacturer_address'] ) ) : ?>
								<?php echo nl2br( esc_html( $data['manufacturer_address'] ) ); ?><br />
							<?php endif; ?>
							<?php if ( ! empty( $data['manufacturer_email'] ) ) : ?>
								<span><?php echo esc_html( $labels['contact'] . ': ' . $data['manufacturer_email'] ); ?></span>
							<?php endif; ?>
						</p>
					</div>
				<?php endif; ?>

				<?php if ( ! empty( $data['eu_responsible_name'] ) ) : ?>
					<div class="sg-gpsr-item">
						<strong><?php echo esc_html( $labels['eu_responsible'] ); ?></strong>
						<p>
							<?php echo esc_html( $data['eu_responsible_name'] ); ?><br />
							<?php if ( ! empty( $data['eu_responsible_addr'] ) ) : ?>
								<?php echo nl2br( esc_html( $data['eu_responsible_addr'] ) ); ?><br />
							<?php endif; ?>
							<?php if ( ! empty( $data['eu_responsible_email'] ) ) : ?>
								<span><?php echo esc_html( $labels['contact'] . ': ' . $data['eu_responsible_email'] ); ?></span>
							<?php endif; ?>
						</p>
					</div>
				<?php endif; ?>
			</div>

			<?php if ( ! empty( $data['safety_warnings'] ) ) : ?>
				<div class="sg-gpsr-safety">
					<strong><?php echo esc_html( $labels['safety'] ); ?></strong>
					<div><?php echo wp_kses_post( wpautop( $data['safety_warnings'] ) ); ?></div>
				</div>
			<?php endif; ?>

			<?php if ( ! empty( $data['ce_marking'] ) ) : ?>
				<div class="sg-gpsr-footer">
					<span class="sg-gpsr-verified">&#10003; <?php echo esc_html( $labels['ce_badge'] ); ?></span>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}
}

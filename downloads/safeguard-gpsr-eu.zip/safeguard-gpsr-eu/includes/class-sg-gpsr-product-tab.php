<?php
/**
 * WooCommerce Product Edit "GPSR UE" Data Tab.
 *
 * @package SafeGuard_GPSR_EU
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SG_GPSR_Product_Tab {

	/**
	 * Register product tab hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_filter( 'woocommerce_product_data_tabs', array( __CLASS__, 'add_product_data_tab' ) );
		add_action( 'woocommerce_product_data_panels', array( __CLASS__, 'render_product_data_panel' ) );
		add_action( 'woocommerce_process_product_meta', array( __CLASS__, 'save_product_data_panel' ) );
	}

	/**
	 * Add GPSR UE tab to WooCommerce product edit screen.
	 *
	 * @param array<string, array<string, mixed>> $tabs Existing tabs.
	 * @return array<string, array<string, mixed>>
	 */
	public static function add_product_data_tab( $tabs ) {
		$tabs['sg_gpsr_eu'] = array(
			'label'    => __( 'GPSR UE', 'safeguard-gpsr-eu-for-woocommerce' ),
			'target'   => 'sg_gpsr_eu_product_data',
			'class'    => array( 'show_if_simple', 'show_if_variable', 'show_if_grouped', 'show_if_external' ),
			'priority' => 65,
		);
		return $tabs;
	}

	/**
	 * Render GPSR UE fields in product data panel.
	 *
	 * @return void
	 */
	public static function render_product_data_panel() {
		global $post;
		$product_id = $post ? (int) $post->ID : 0;
		$data       = SG_GPSR_Helpers::get_product_gpsr_data( $product_id );
		?>
		<div id="sg_gpsr_eu_product_data" class="panel woocommerce_options_panel hidden">
			<?php wp_nonce_field( 'sg_gpsr_save_product', 'sg_gpsr_product_nonce' ); ?>
			<div class="options_group">
				<p class="form-field">
					<strong><?php echo esc_html__( 'Manufacturer Details (EU Regulation 2023/988)', 'safeguard-gpsr-eu-for-woocommerce' ); ?></strong>
				</p>
				<?php
				woocommerce_wp_text_input(
					array(
						'id'          => '_sg_gpsr_manufacturer_name',
						'label'       => __( 'Manufacturer Name', 'safeguard-gpsr-eu-for-woocommerce' ),
						'value'       => $data['manufacturer_name'],
						'placeholder' => __( 'e.g. Nordic Sound GmbH', 'safeguard-gpsr-eu-for-woocommerce' ),
					)
				);
				woocommerce_wp_textarea_input(
					array(
						'id'          => '_sg_gpsr_manufacturer_address',
						'label'       => __( 'Manufacturer Address', 'safeguard-gpsr-eu-for-woocommerce' ),
						'value'       => $data['manufacturer_address'],
						'placeholder' => __( 'Full postal street address, city, postal code, country', 'safeguard-gpsr-eu-for-woocommerce' ),
					)
				);
				woocommerce_wp_text_input(
					array(
						'id'          => '_sg_gpsr_manufacturer_email',
						'label'       => __( 'Manufacturer Email / URL', 'safeguard-gpsr-eu-for-woocommerce' ),
						'value'       => $data['manufacturer_email'],
						'placeholder' => 'compliance@manufacturer.eu',
					)
				);
				?>
			</div>

			<div class="options_group">
				<p class="form-field">
					<strong><?php echo esc_html__( 'EU Responsible Person (Art. 16 GPSR)', 'safeguard-gpsr-eu-for-woocommerce' ); ?></strong>
				</p>
				<?php
				woocommerce_wp_text_input(
					array(
						'id'          => '_sg_gpsr_eu_responsible_name',
						'label'       => __( 'EU Responsible Name', 'safeguard-gpsr-eu-for-woocommerce' ),
						'value'       => $data['eu_responsible_name'],
						'placeholder' => __( 'e.g. EU Compliance Representative GmbH', 'safeguard-gpsr-eu-for-woocommerce' ),
					)
				);
				woocommerce_wp_textarea_input(
					array(
						'id'          => '_sg_gpsr_eu_responsible_address',
						'label'       => __( 'EU Responsible Address', 'safeguard-gpsr-eu-for-woocommerce' ),
						'value'       => $data['eu_responsible_addr'],
						'placeholder' => __( 'EU postal address', 'safeguard-gpsr-eu-for-woocommerce' ),
					)
				);
				woocommerce_wp_text_input(
					array(
						'id'          => '_sg_gpsr_eu_responsible_email',
						'label'       => __( 'EU Responsible Email', 'safeguard-gpsr-eu-for-woocommerce' ),
						'value'       => $data['eu_responsible_email'],
						'placeholder' => 'gpsr@eu-representative.eu',
					)
				);
				?>
			</div>

			<div class="options_group">
				<?php
				woocommerce_wp_textarea_input(
					array(
						'id'          => '_sg_gpsr_safety_warnings',
						'label'       => __( 'Safety Warnings & Instructions', 'safeguard-gpsr-eu-for-woocommerce' ),
						'value'       => $data['safety_warnings'],
						'desc_tip'    => true,
						'description' => __( 'Required safety warnings, age restrictions, or usage instructions in the store language.', 'safeguard-gpsr-eu-for-woocommerce' ),
					)
				);
				woocommerce_wp_checkbox(
					array(
						'id'          => '_sg_gpsr_ce_marking',
						'label'       => __( 'CE Conformity Marking', 'safeguard-gpsr-eu-for-woocommerce' ),
						'value'       => $data['ce_marking'] ? 'yes' : 'no',
						'description' => __( 'Product complies with applicable EU CE conformity directives.', 'safeguard-gpsr-eu-for-woocommerce' ),
					)
				);
				?>
			</div>
		</div>
		<?php
	}

	/**
	 * Save GPSR UE product metadata securely.
	 *
	 * @param int $product_id Product ID.
	 * @return void
	 */
	public static function save_product_data_panel( $product_id ) {
		if ( ! isset( $_POST['sg_gpsr_product_nonce'] ) ) {
			return;
		}
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['sg_gpsr_product_nonce'] ) ), 'sg_gpsr_save_product' ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $product_id ) ) {
			return;
		}

		$raw = array(
			'manufacturer_name'    => isset( $_POST['_sg_gpsr_manufacturer_name'] ) ? $_POST['_sg_gpsr_manufacturer_name'] : '',
			'manufacturer_address' => isset( $_POST['_sg_gpsr_manufacturer_address'] ) ? $_POST['_sg_gpsr_manufacturer_address'] : '',
			'manufacturer_email'   => isset( $_POST['_sg_gpsr_manufacturer_email'] ) ? $_POST['_sg_gpsr_manufacturer_email'] : '',
			'eu_responsible_name'  => isset( $_POST['_sg_gpsr_eu_responsible_name'] ) ? $_POST['_sg_gpsr_eu_responsible_name'] : '',
			'eu_responsible_addr'  => isset( $_POST['_sg_gpsr_eu_responsible_address'] ) ? $_POST['_sg_gpsr_eu_responsible_address'] : '',
			'eu_responsible_email' => isset( $_POST['_sg_gpsr_eu_responsible_email'] ) ? $_POST['_sg_gpsr_eu_responsible_email'] : '',
			'safety_warnings'      => isset( $_POST['_sg_gpsr_safety_warnings'] ) ? $_POST['_sg_gpsr_safety_warnings'] : '',
			'ce_marking'           => isset( $_POST['_sg_gpsr_ce_marking'] ) ? 'yes' : 'no',
		);

		SG_GPSR_Helpers::save_product_gpsr_data( $product_id, $raw );
	}
}

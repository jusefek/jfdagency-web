<?php
/**
 * Admin settings, reusable GPSR profiles, and 1-click bulk apply.
 *
 * @package SafeGuard_GPSR_EU
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SG_GPSR_Admin {

	/**
	 * Register admin hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_post_sg_gpsr_save_settings', array( __CLASS__, 'handle_save_settings' ) );
		add_action( 'admin_post_sg_gpsr_save_profile', array( __CLASS__, 'handle_save_profile' ) );
		add_action( 'admin_post_sg_gpsr_apply_profile', array( __CLASS__, 'handle_apply_profile' ) );
		add_action( 'admin_post_sg_gpsr_delete_profile', array( __CLASS__, 'handle_delete_profile' ) );
	}

	/**
	 * Register WooCommerce submenu page.
	 *
	 * @return void
	 */
	public static function register_menu() {
		add_submenu_page(
			'woocommerce',
			__( 'SafeGuard GPSR EU', 'safeguard-gpsr-eu-for-woocommerce' ),
			__( 'SafeGuard GPSR EU', 'safeguard-gpsr-eu-for-woocommerce' ),
			'manage_woocommerce',
			'safeguard-gpsr-eu-for-woocommerce',
			array( __CLASS__, 'render_admin_page' )
		);
	}

	/**
	 * Save storefront display settings.
	 *
	 * @return void
	 */
	public static function handle_save_settings() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Unauthorized access.', 'safeguard-gpsr-eu-for-woocommerce' ) );
		}
		check_admin_referer( 'sg_gpsr_settings_action', 'sg_gpsr_settings_nonce' );

		$display_position = isset( $_POST['display_position'] ) ? sanitize_key( wp_unslash( $_POST['display_position'] ) ) : 'summary';
		if ( ! in_array( $display_position, array( 'summary', 'tab' ), true ) ) {
			$display_position = 'summary';
		}

		update_option(
			'sg_gpsr_settings',
			array(
				'display_position' => $display_position,
			)
		);

		wp_safe_redirect( add_query_arg( array( 'page' => 'safeguard-gpsr-eu-for-woocommerce', 'sg_notice' => 'settings_saved' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Save or update a reusable Manufacturer / EU Responsible profile.
	 *
	 * @return void
	 */
	public static function handle_save_profile() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Unauthorized access.', 'safeguard-gpsr-eu-for-woocommerce' ) );
		}
		check_admin_referer( 'sg_gpsr_profile_action', 'sg_gpsr_profile_nonce' );

		$profile_name = isset( $_POST['profile_name'] ) ? sanitize_text_field( wp_unslash( $_POST['profile_name'] ) ) : '';
		if ( empty( $profile_name ) ) {
			wp_safe_redirect( add_query_arg( array( 'page' => 'safeguard-gpsr-eu-for-woocommerce', 'sg_notice' => 'missing_name' ), admin_url( 'admin.php' ) ) );
			exit;
		}

		$profile_id = isset( $_POST['profile_id'] ) && ! empty( $_POST['profile_id'] )
			? sanitize_key( wp_unslash( $_POST['profile_id'] ) )
			: sanitize_title( $profile_name ) . '_' . substr( md5( $profile_name . microtime() ), 0, 6 );

		$data = SG_GPSR_Helpers::sanitize_profile_data(
			array(
				'manufacturer_name'    => isset( $_POST['manufacturer_name'] ) ? $_POST['manufacturer_name'] : '',
				'manufacturer_address' => isset( $_POST['manufacturer_address'] ) ? $_POST['manufacturer_address'] : '',
				'manufacturer_email'   => isset( $_POST['manufacturer_email'] ) ? $_POST['manufacturer_email'] : '',
				'eu_responsible_name'  => isset( $_POST['eu_responsible_name'] ) ? $_POST['eu_responsible_name'] : '',
				'eu_responsible_addr'  => isset( $_POST['eu_responsible_addr'] ) ? $_POST['eu_responsible_addr'] : '',
				'eu_responsible_email' => isset( $_POST['eu_responsible_email'] ) ? $_POST['eu_responsible_email'] : '',
				'safety_warnings'      => isset( $_POST['safety_warnings'] ) ? $_POST['safety_warnings'] : '',
				'ce_marking'           => isset( $_POST['ce_marking'] ) ? 'yes' : 'no',
			)
		);

		$profiles = get_option( 'sg_gpsr_profiles', array() );
		if ( ! is_array( $profiles ) ) {
			$profiles = array();
		}

		$profiles[ $profile_id ] = array_merge(
			array(
				'id'   => $profile_id,
				'name' => $profile_name,
			),
			$data
		);

		update_option( 'sg_gpsr_profiles', $profiles );

		wp_safe_redirect( add_query_arg( array( 'page' => 'safeguard-gpsr-eu-for-woocommerce', 'sg_notice' => 'profile_saved' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Delete a saved GPSR profile.
	 *
	 * @return void
	 */
	public static function handle_delete_profile() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Unauthorized access.', 'safeguard-gpsr-eu-for-woocommerce' ) );
		}
		check_admin_referer( 'sg_gpsr_delete_action', 'sg_gpsr_delete_nonce' );

		$profile_id = isset( $_POST['profile_id'] ) ? sanitize_key( wp_unslash( $_POST['profile_id'] ) ) : '';
		$profiles   = get_option( 'sg_gpsr_profiles', array() );

		if ( is_array( $profiles ) && isset( $profiles[ $profile_id ] ) ) {
			unset( $profiles[ $profile_id ] );
			update_option( 'sg_gpsr_profiles', $profiles );
		}

		wp_safe_redirect( add_query_arg( array( 'page' => 'safeguard-gpsr-eu-for-woocommerce', 'sg_notice' => 'profile_deleted' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Bulk-apply a saved GPSR profile to all products in a category or brand term.
	 *
	 * @return void
	 */
	public static function handle_apply_profile() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Unauthorized access.', 'safeguard-gpsr-eu-for-woocommerce' ) );
		}
		check_admin_referer( 'sg_gpsr_apply_action', 'sg_gpsr_apply_nonce' );

		$profile_id = isset( $_POST['profile_id'] ) ? sanitize_key( wp_unslash( $_POST['profile_id'] ) ) : '';
		$target     = isset( $_POST['target_term'] ) ? sanitize_text_field( wp_unslash( $_POST['target_term'] ) ) : '';
		$profiles   = get_option( 'sg_gpsr_profiles', array() );

		if ( ! is_array( $profiles ) || ! isset( $profiles[ $profile_id ] ) || false === strpos( $target, '|' ) ) {
			wp_safe_redirect( add_query_arg( array( 'page' => 'safeguard-gpsr-eu-for-woocommerce', 'sg_notice' => 'apply_error' ), admin_url( 'admin.php' ) ) );
			exit;
		}

		list( $taxonomy, $term_id_raw ) = explode( '|', $target, 2 );
		$taxonomy                       = sanitize_key( $taxonomy );
		$term_id                        = absint( $term_id_raw );

		if ( ! taxonomy_exists( $taxonomy ) || $term_id <= 0 ) {
			wp_safe_redirect( add_query_arg( array( 'page' => 'safeguard-gpsr-eu-for-woocommerce', 'sg_notice' => 'apply_error' ), admin_url( 'admin.php' ) ) );
			exit;
		}

		$product_ids = get_posts(
			array(
				'post_type'      => 'product',
				'post_status'    => array( 'publish', 'draft', 'private' ),
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'tax_query'      => array(
					array(
						'taxonomy' => $taxonomy,
						'field'    => 'term_id',
						'terms'    => $term_id,
					),
				),
			)
		);

		$updated = 0;
		foreach ( $product_ids as $pid ) {
			SG_GPSR_Helpers::save_product_gpsr_data( (int) $pid, $profiles[ $profile_id ] );
			++$updated;
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'       => 'safeguard-gpsr-eu-for-woocommerce',
					'sg_notice'  => 'applied',
					'sg_updated' => $updated,
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Collect available product categories and brand attributes for bulk target dropdown.
	 *
	 * @return array<string, string>
	 */
	private static function get_target_terms_options() {
		$options    = array();
		$taxonomies = array( 'product_cat' );

		if ( taxonomy_exists( 'product_brand' ) ) {
			$taxonomies[] = 'product_brand';
		}

		if ( function_exists( 'wc_get_attribute_taxonomies' ) ) {
			foreach ( wc_get_attribute_taxonomies() as $attr ) {
				$tax = wc_attribute_taxonomy_name( $attr->attribute_name );
				if ( taxonomy_exists( $tax ) ) {
					$taxonomies[] = $tax;
				}
			}
		}

		foreach ( $taxonomies as $tax ) {
			$tax_obj = get_taxonomy( $tax );
			$terms   = get_terms(
				array(
					'taxonomy'   => $tax,
					'hide_empty' => false,
				)
			);
			if ( is_wp_error( $terms ) || empty( $terms ) ) {
				continue;
			}
			$prefix = $tax_obj ? $tax_obj->labels->singular_name : $tax;
			foreach ( $terms as $term ) {
				$options[ $tax . '|' . $term->term_id ] = $prefix . ': ' . $term->name . ' (' . (int) $term->count . ')';
			}
		}

		return $options;
	}

	/**
	 * Render admin page HTML.
	 *
	 * @return void
	 */
	public static function render_admin_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		$settings   = get_option( 'sg_gpsr_settings', array() );
		$profiles   = get_option( 'sg_gpsr_profiles', array() );
		$display    = isset( $settings['display_position'] ) ? $settings['display_position'] : 'summary';
		$terms      = self::get_target_terms_options();
		$notice     = isset( $_GET['sg_notice'] ) ? sanitize_key( wp_unslash( $_GET['sg_notice'] ) ) : '';
		$updated    = isset( $_GET['sg_updated'] ) ? absint( wp_unslash( $_GET['sg_updated'] ) ) : 0;
		?>
		<div class="wrap">
			<h1><?php echo esc_html__( 'SafeGuard GPSR EU for WooCommerce', 'safeguard-gpsr-eu-for-woocommerce' ); ?></h1>
			<p><?php echo esc_html__( 'Comply with Regulation (EU) 2023/988 (GPSR) across your catalog with reusable manufacturer profiles and automatic multilingual storefront blocks.', 'safeguard-gpsr-eu-for-woocommerce' ); ?></p>

			<?php if ( 'settings_saved' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html__( 'Settings saved.', 'safeguard-gpsr-eu-for-woocommerce' ); ?></p></div>
			<?php elseif ( 'profile_saved' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html__( 'GPSR compliance profile saved.', 'safeguard-gpsr-eu-for-woocommerce' ); ?></p></div>
			<?php elseif ( 'profile_deleted' === $notice ) : ?>
				<div class="notice notice-info is-dismissible"><p><?php echo esc_html__( 'Profile deleted.', 'safeguard-gpsr-eu-for-woocommerce' ); ?></p></div>
			<?php elseif ( 'applied' === $notice ) : ?>
				<div class="notice notice-success is-dismissible">
					<p>
						<?php
						/* translators: %d: number of updated products */
						echo esc_html( sprintf( __( 'GPSR profile applied to %d products.', 'safeguard-gpsr-eu-for-woocommerce' ), $updated ) );
						?>
					</p>
				</div>
			<?php elseif ( 'missing_name' === $notice || 'apply_error' === $notice ) : ?>
				<div class="notice notice-error is-dismissible"><p><?php echo esc_html__( 'Please select a valid profile and target category/brand.', 'safeguard-gpsr-eu-for-woocommerce' ); ?></p></div>
			<?php endif; ?>

			<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:16px;align-items:start;">
				<div class="card" style="max-width:none;padding:16px;">
					<h2><?php echo esc_html__( '1. Create Reusable Brand / Manufacturer Profile', 'safeguard-gpsr-eu-for-woocommerce' ); ?></h2>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="sg_gpsr_save_profile" />
						<?php wp_nonce_field( 'sg_gpsr_profile_action', 'sg_gpsr_profile_nonce' ); ?>
						<table class="form-table">
							<tr>
								<th><label for="sg_profile_name"><?php echo esc_html__( 'Profile Name', 'safeguard-gpsr-eu-for-woocommerce' ); ?></label></th>
								<td><input id="sg_profile_name" name="profile_name" type="text" class="regular-text" required placeholder="e.g. Nordic Sound GmbH" /></td>
							</tr>
							<tr>
								<th><label for="sg_mfg_name"><?php echo esc_html__( 'Manufacturer Name', 'safeguard-gpsr-eu-for-woocommerce' ); ?></label></th>
								<td><input id="sg_mfg_name" name="manufacturer_name" type="text" class="regular-text" required /></td>
							</tr>
							<tr>
								<th><label for="sg_mfg_addr"><?php echo esc_html__( 'Manufacturer Address', 'safeguard-gpsr-eu-for-woocommerce' ); ?></label></th>
								<td><textarea id="sg_mfg_addr" name="manufacturer_address" rows="2" class="large-text" required></textarea></td>
							</tr>
							<tr>
								<th><label for="sg_mfg_email"><?php echo esc_html__( 'Manufacturer Email / URL', 'safeguard-gpsr-eu-for-woocommerce' ); ?></label></th>
								<td><input id="sg_mfg_email" name="manufacturer_email" type="text" class="regular-text" required /></td>
							</tr>
							<tr>
								<th><label for="sg_eu_name"><?php echo esc_html__( 'EU Responsible Person', 'safeguard-gpsr-eu-for-woocommerce' ); ?></label></th>
								<td><input id="sg_eu_name" name="eu_responsible_name" type="text" class="regular-text" required /></td>
							</tr>
							<tr>
								<th><label for="sg_eu_addr"><?php echo esc_html__( 'EU Responsible Address', 'safeguard-gpsr-eu-for-woocommerce' ); ?></label></th>
								<td><textarea id="sg_eu_addr" name="eu_responsible_addr" rows="2" class="large-text" required></textarea></td>
							</tr>
							<tr>
								<th><label for="sg_eu_email"><?php echo esc_html__( 'EU Responsible Email', 'safeguard-gpsr-eu-for-woocommerce' ); ?></label></th>
								<td><input id="sg_eu_email" name="eu_responsible_email" type="email" class="regular-text" required /></td>
							</tr>
							<tr>
								<th><label for="sg_safety"><?php echo esc_html__( 'Safety Warnings', 'safeguard-gpsr-eu-for-woocommerce' ); ?></label></th>
								<td><textarea id="sg_safety" name="safety_warnings" rows="2" class="large-text"></textarea></td>
							</tr>
							<tr>
								<th><?php echo esc_html__( 'CE Conformity', 'safeguard-gpsr-eu-for-woocommerce' ); ?></th>
								<td><label><input type="checkbox" name="ce_marking" value="yes" checked="checked" /> <?php echo esc_html__( 'Include CE conformity badge', 'safeguard-gpsr-eu-for-woocommerce' ); ?></label></td>
							</tr>
						</table>
						<?php submit_button( __( 'Save GPSR Profile', 'safeguard-gpsr-eu-for-woocommerce' ) ); ?>
					</form>
				</div>

				<div>
					<div class="card" style="max-width:none;padding:16px;margin-bottom:20px;">
						<h2><?php echo esc_html__( '2. Storefront Display Settings', 'safeguard-gpsr-eu-for-woocommerce' ); ?></h2>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<input type="hidden" name="action" value="sg_gpsr_save_settings" />
							<?php wp_nonce_field( 'sg_gpsr_settings_action', 'sg_gpsr_settings_nonce' ); ?>
							<table class="form-table">
								<tr>
									<th><label for="sg_display_position"><?php echo esc_html__( 'Product Page Position', 'safeguard-gpsr-eu-for-woocommerce' ); ?></label></th>
									<td>
										<select id="sg_display_position" name="display_position">
											<option value="summary" <?php selected( $display, 'summary' ); ?>><?php echo esc_html__( 'Box below Add to Cart (Summary)', 'safeguard-gpsr-eu-for-woocommerce' ); ?></option>
											<option value="tab" <?php selected( $display, 'tab' ); ?>><?php echo esc_html__( 'Additional Product Tab (GPSR EU)', 'safeguard-gpsr-eu-for-woocommerce' ); ?></option>
										</select>
									</td>
								</tr>
							</table>
							<?php submit_button( __( 'Save Settings', 'safeguard-gpsr-eu-for-woocommerce' ) ); ?>
						</form>
						<p class="description" style="margin-top:8px;padding-top:10px;border-top:1px solid #dcdcde;">
							<?php
							printf(
								/* translators: %s: link to external companion tools */
								esc_html__( 'All features in this plugin are free and unlimited. For standalone CSV import/export and sector compliance templates outside WordPress, visit %s.', 'safeguard-gpsr-eu-for-woocommerce' ),
								'<a href="' . esc_url( 'https://jfdagency.com/safeguard-gpsr/' ) . '" target="_blank" rel="noopener noreferrer">jfdagency.com/safeguard-gpsr/</a>'
							);
							?>
						</p>
					</div>

					<div class="card" style="max-width:none;padding:16px;">
						<h2><?php echo esc_html__( '3. 1-Click Bulk Apply by Brand / Category', 'safeguard-gpsr-eu-for-woocommerce' ); ?></h2>
						<?php if ( empty( $profiles ) ) : ?>
							<p><?php echo esc_html__( 'Create a reusable GPSR profile first to apply it across your catalog.', 'safeguard-gpsr-eu-for-woocommerce' ); ?></p>
						<?php else : ?>
							<table class="widefat striped">
								<thead>
									<tr>
										<th><?php echo esc_html__( 'Profile', 'safeguard-gpsr-eu-for-woocommerce' ); ?></th>
										<th><?php echo esc_html__( 'EU Responsible Person', 'safeguard-gpsr-eu-for-woocommerce' ); ?></th>
										<th><?php echo esc_html__( 'Bulk Apply / Delete', 'safeguard-gpsr-eu-for-woocommerce' ); ?></th>
									</tr>
								</thead>
								<tbody>
									<?php foreach ( $profiles as $pid => $prof ) : ?>
										<tr>
											<td><strong><?php echo esc_html( $prof['name'] ); ?></strong><br /><small><?php echo esc_html( $prof['manufacturer_name'] ); ?></small></td>
											<td><?php echo esc_html( $prof['eu_responsible_name'] ); ?><br /><small><?php echo esc_html( $prof['eu_responsible_email'] ); ?></small></td>
											<td>
												<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex;gap:6px;align-items:center;margin-bottom:6px;">
													<input type="hidden" name="action" value="sg_gpsr_apply_profile" />
													<input type="hidden" name="profile_id" value="<?php echo esc_attr( $pid ); ?>" />
													<?php wp_nonce_field( 'sg_gpsr_apply_action', 'sg_gpsr_apply_nonce' ); ?>
													<select name="target_term" style="max-width:190px;">
														<?php foreach ( $terms as $val => $label ) : ?>
															<option value="<?php echo esc_attr( $val ); ?>"><?php echo esc_html( $label ); ?></option>
														<?php endforeach; ?>
													</select>
													<button type="submit" class="button button-primary button-small"><?php echo esc_html__( 'Apply 1-Click', 'safeguard-gpsr-eu-for-woocommerce' ); ?></button>
												</form>
												<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
													<input type="hidden" name="action" value="sg_gpsr_delete_profile" />
													<input type="hidden" name="profile_id" value="<?php echo esc_attr( $pid ); ?>" />
													<?php wp_nonce_field( 'sg_gpsr_delete_action', 'sg_gpsr_delete_nonce' ); ?>
													<button type="submit" class="button-link-delete" style="border:none;background:none;color:#b32d2e;cursor:pointer;padding:0;"><?php echo esc_html__( 'Delete', 'safeguard-gpsr-eu-for-woocommerce' ); ?></button>
												</form>
											</td>
										</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
		<?php
	}
}

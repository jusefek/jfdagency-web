<?php
/**
 * Plugin Name:       SafeGuard GPSR EU for WooCommerce
 * Plugin URI:        https://tryjfdagency.com/safeguard-gpsr-eu
 * Description:       Automate EU General Product Safety Regulation (EU) 2023/988 (GPSR) compliance for WooCommerce with per-product fields, 1-click brand/category profiles, and a multilingual storefront block.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            TryJFD Agency
 * Author URI:        https://tryjfdagency.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       safeguard-gpsr-eu-for-woocommerce
 * WC requires at least: 7.0
 * WC tested up to:   9.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SG_GPSR_VERSION', '1.0.0' );
define( 'SG_GPSR_PLUGIN_FILE', __FILE__ );
define( 'SG_GPSR_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SG_GPSR_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'SG_GPSR_FREE_LIMIT', 25 );

/**
 * Declare WooCommerce HPOS compatibility.
 */
add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
				'custom_order_tables',
				__FILE__,
				true
			);
		}
	}
);

/**
 * Bootstrap plugin after all plugins are loaded.
 */
function sg_gpsr_init() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', 'sg_gpsr_woocommerce_missing_notice' );
		return;
	}

	require_once SG_GPSR_PLUGIN_DIR . 'includes/class-sg-gpsr-helpers.php';
	require_once SG_GPSR_PLUGIN_DIR . 'includes/class-sg-gpsr-product-tab.php';
	require_once SG_GPSR_PLUGIN_DIR . 'includes/class-sg-gpsr-admin.php';
	require_once SG_GPSR_PLUGIN_DIR . 'includes/class-sg-gpsr-frontend.php';

	SG_GPSR_Product_Tab::init();
	SG_GPSR_Admin::init();
	SG_GPSR_Frontend::init();
}
add_action( 'plugins_loaded', 'sg_gpsr_init' );

/**
 * Admin notice when WooCommerce is inactive.
 */
function sg_gpsr_woocommerce_missing_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	echo '<div class="notice notice-error"><p>';
	echo esc_html__(
		'SafeGuard GPSR EU for WooCommerce requires WooCommerce to be installed and active.',
		'safeguard-gpsr-eu-for-woocommerce'
	);
	echo '</p></div>';
}

/**
 * Initialize default plugin options on activation.
 */
function sg_gpsr_activate() {
	if ( false === get_option( 'sg_gpsr_settings' ) ) {
		add_option(
			'sg_gpsr_settings',
			array(
				'display_position' => 'summary',
				'license_key'      => '',
				'license_status'   => 'free',
			)
		);
	}
	if ( false === get_option( 'sg_gpsr_profiles' ) ) {
		add_option( 'sg_gpsr_profiles', array() );
	}
}
register_activation_hook( __FILE__, 'sg_gpsr_activate' );
